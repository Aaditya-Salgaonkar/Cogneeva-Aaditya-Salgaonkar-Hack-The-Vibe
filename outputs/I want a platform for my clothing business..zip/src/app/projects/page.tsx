<div class="container mx-auto px-6 py-4" *ngIf="user">
  <h1 class="text-3xl font-bold text-center mb-6">Your Projects</h1>
  <div class="flex flex-wrap">
    <div
      class="w-full md:w-1/3 p-4 flex flex-col flex-grow flex-shrink"
      *ngFor="let project of projects"
    >
      <div
        class="flex-1 bg-white text-gray-600 rounded-t rounded-b-none overflow-hidden shadow"
      >
        <div class="p-8 text-3xl text-center border-b-4">{{ project.name }}</div>
        <ul class="w-full text-center text-sm">
          <li class="border-b py-4">Created: {{ project.createdAt }}</li>
          <li class="border-b py-4">Updated: {{ project.updatedAt }}</li>
        </ul>
      </div>
      <div
        class="flex-none mt-auto bg-white rounded-b rounded-t-none overflow-hidden shadow p-6"
      >
        <div class="flex items-center justify-start">
          <button
            class="flex items-center justify-start bg-blue-500 hover:bg-blue-700 rounded-full text-white font-bold py-2 px-4 shadow-lg mr-2"
          >
            <svg
              class="fill-current w-4 h-4 mr-2"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
            >
              <path
                d="M13.414 10l2.828-2.829-1.415-1.415L10 8.586 7.172 5.757 5.5 7.586l4 4z"
              />
              <path d="M5.5 14.5l4-4 4 4M11 10h.01" />
            </svg>
            Edit
          </button>
          <button
            class="flex items-center justify-start bg-red-500 hover:bg-red-700 rounded-full text-white font-bold py-2 px-4 shadow-lg"
          >
            <svg
              class="fill-current w-4 h-4 mr-2"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
            >
              <path
                d="M10 0C4.5 0 0 4.5 0 10s4.5 10 10 10 10-4.5 10-10S15.5 0 10 0zm4.4 13.6c.4.4.4 1 0 1.4s-1 .4-1.4 0L10 11.4l-3.6 3.6c-.4.4-1 .4-1.4 0-.4-.4-.4-1 0-1.4L8.6 10 5 6.4c-.4-.4-.4-1 0-1.4.4-.4 1-.4 1.4 0L10 8.6l3.6-3.6c.4-.4 1-.4 1.4 0 .4.4.4 1 0 1.4L11.4 10l3.6 3.6z"
              />
            </svg>
            Delete
          </button>
        </div>
      </div>
    </div>
  </div>
</div>