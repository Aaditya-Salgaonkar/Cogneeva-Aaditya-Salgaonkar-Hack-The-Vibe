import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import * as yup from 'yup';
import { PrismaClient } from '@prisma/client';
import { Button, Form, Input } from 'antd';
import 'antd/dist/reset.css';
import './styles.css';

const prisma = new PrismaClient();

const schema = yup.object().shape({
  name: yup.string().required('Name is required'),
  description: yup.string().required('Description is required'),
});

const NewProjectPage = () => {
  const { register, handleSubmit, errors } = useForm({
    resolver: yupResolver(schema),
  });

  const onSubmit = async (data) => {
    try {
      await prisma.project.create({
        data,
      });
      alert('Project created successfully!');
    } catch (error) {
      console.error(error);
      alert('Error creating project');
    }
  };

  return (
    <div className="flex items-center justify-center h-screen">
      <Form onFinish={handleSubmit(onSubmit)} className="w-1/3">
        <Form.Item
          label="Name"
          name="name"
          validateStatus={errors.name ? 'error' : ''}
          help={errors.name?.message}
        >
          <Input ref={register} />
        </Form.Item>
        <Form.Item
          label="Description"
          name="description"
          validateStatus={errors.description ? 'error' : ''}
          help={errors.description?.message}
        >
          <Input.TextArea ref={register} />
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Create Project
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default NewProjectPage;