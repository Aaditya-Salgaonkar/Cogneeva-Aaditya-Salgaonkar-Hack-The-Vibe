import { ClerkProvider, SignedIn, SignedOut, RedirectToSignIn } from "@clerk/clerk-react";

<ClerkProvider frontendApi="your-frontend-api">
  <SignedIn>
    {/* Show user's profile or any signed-in only content here */}
    <p>Welcome, {data.firstName}!</p>
    <button>Sign out</button>
  </SignedIn>
  <SignedOut>
    {/* Show sign-in and sign-up buttons here */}
    <RedirectToSignIn />
  </SignedOut>
</ClerkProvider>