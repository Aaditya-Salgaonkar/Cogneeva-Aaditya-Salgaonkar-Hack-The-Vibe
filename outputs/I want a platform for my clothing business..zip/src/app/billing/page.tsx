<html>
  <head>
    <title>Subscription Details</title>
  </head>
  <body>
    <h1>Your Subscription Details</h1>
    <table>
      <thead>
        <tr>
          <th>Product</th>
          <th>Price</th>
          <th>Quantity</th>
          <th>Next Billing Date</th>
        </tr>
      </thead>
      <tbody>
        <!-- Loop through subscriptions and display details -->
        <% subscriptions.forEach(subscription => { %>
          <tr>
            <td><%= subscription.product %></td>
            <td><%= subscription.price %></td>
            <td><%= subscription.quantity %></td>
            <td><%= subscription.next_billing_date %></td>
          </tr>
        <% }); %>
      </tbody>
    </table>
    <form action="/api/billing" method="POST">
      <button type="submit">Manage Subscription</button>
    </form>
    <script src="https://js.stripe.com/v3/"></script>
    <script>
      // Open Stripe Billing portal on form submit
      const form = document.querySelector('form');
      form.addEventListener('submit', function(event) {
        event.preventDefault();
        const stripe = Stripe('<YOUR_STRIPE_PUBLISHABLE_KEY>');
        stripe.redirectToCheckout({
          sessionId: '<YOUR_STRIPE_CHECKOUT_SESSION_ID>'
        }).then(function (result) {
          // If redirectToCheckout fails due to a browser or network
          // error, you should display the localized error message to your
          // customer using error.message.
          if (result.error) {
            alert(result.error.message);
          }
        });
      });
    </script>
  </body>
</html>