<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Saas App</title>
 <link href="https://cdn.jsdelivr.net/npm/tailwindcss@3.0.2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
 <!-- Hero Section -->
 <section class="bg-cover bg-center h-screen flex items-center" style="background-image: url('https://source.unsplash.com/random/1600x900/?saas,technology')">
 <div class="container mx-auto text-center">
 <h1 class="text-5xl font-bold text-white">Welcome to Saas App</h1>
 <p class="text-xl text-white mt-4">We provide the best solution for your business.</p>
 <a href="#features" class="bg-white hover:bg-gray-100 text-gray-800 font-semibold py-2 px-4 rounded inline-block mt-8">Learn More</a>
 </div>
 </section>

 <!-- Feature Grid -->
 <section id="features" class="container mx-auto py-16">
 <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
 <div class="bg-white p-8 rounded shadow">
 <h2 class="text-2xl font-bold mb-4">Feature 1</h2>
 <p class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.</p>
 </div>
 <div class="bg-white p-8 rounded shadow">
 <h2 class="text-2xl font-bold mb-4">Feature 2</h2>
 <p class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.</p>
 </div>
 <div class="bg-white p-8 rounded shadow">
 <h2 class="text-2xl font-bold mb-4">Feature 3</h2>
 <p class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.</p>
 </div>
 </div>
 </section>

 <!-- Customer Testimonials -->
 <section id="testimonials" class="bg-gray-100 py-16">
 <div class="container mx-auto text-center">
 <h2 class="text-4xl font-bold mb-12">What Our Customers Say</h2>
 <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
 <div class="bg-white p-8 rounded shadow">
 <p class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.</p>
 <h3 class="text-xl font-bold mt-4">John Doe</h3>
 <p class="text-gray-500">CEO, Acme Inc.</p>
 </div>
 <div class="bg-white p-8 rounded shadow">
 <p class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.</p>
 <h3 class="text-xl font-bold mt-4">Jane Doe</h3>
 <p class="text-gray-500">CTO, Acme Inc.</p>
 </div>
 <div class="bg-white p-8 rounded shadow">
 <p class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.</p>
 <h3 class="text-xl font-bold mt-4">Jim Brown</h3>
 <p class="text-gray-500">CFO, Acme Inc.</p>
 </div>
 </div>
 </div>
 </section>

 <!-- Pricing Section -->
 <section id="pricing" class="container mx-auto py-16">
 <h2 class="text-4xl font-bold mb-12 text-center">Choose Your Plan</h2>
 <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
 <div class="bg-white p-8 rounded shadow">
 <h3 class="text-2xl font-bold mb-4">Basic</h3>
 <p class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.</p>
 <p class="text-3xl font-bold mt-8">$9.99</p>
 <a href="#" class="bg-blue-500 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded inline-block mt-4">Sign Up</a>
 </div>
 <div class="bg-white p-8 rounded shadow">
 <h3 class="text-2xl font-bold mb-4">Pro</h3>
 <p class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.</p>
 <p class="text-3xl font-bold mt-8">$29.99</p>
 <a href="#" class="bg-blue-500 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded inline-block mt-4">Sign Up</a>
 </div>
 <div class="bg-white p-8 rounded shadow">
 <h3 class="text-2xl font-bold mb-4">Enterprise</h3>
 <p class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.</p>
 <p class="text-3xl font-bold mt-8">$99.99</p>
 <a href="#" class="bg-blue-500 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded inline-block mt-4">Sign Up</a>
 </div>
 </div>
 </section>

 <!-- FAQ -->
 <section id="faq" class="container mx-auto py-16">
 <h2 class="text-4xl font-bold mb-12 text-center">Frequently Asked Questions</h2>
 <div class="accordion" id="accordionExample">
 <div class="accordion-item">
 <h2 class="accordion-header" id="headingOne">
 <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
 How does it work?
 </button>
 </h2>
 <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
 <div class="accordion-body">
 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.
 </div>
 </div>
 </div>
 <div class="accordion-item">
 <h2 class="accordion-header" id="headingTwo">
 <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
 Is it easy to use?
 </button>
 </h2>
 <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
 <div class="accordion-body">
 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.
 </div>
 </div>
 </div>
 <div class="accordion-item">
 <h2 class="accordion-header" id="headingThree">
 <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
 How do I get started?
 </button>
 </h2>
 <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
 <div class="accordion-body">
 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.
 </div>
 </div>
 </div>
 </div>
 </section>

 <!-- CTA -->
 <section id="cta" class="bg-blue-500 text-white py-16">
 <div class="container mx-auto text-center">
 <h2 class="text-4xl font-bold mb-4">Ready to Get Started?</h2>
 <p class="text-gray-200">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo, velit et pharetra rhoncus, mi lacus venenatis nisl.</p>
 <a href="#pricing" class="bg-white text-blue-500 font-semibold py-2 px-4 rounded inline-block mt-8">Choose Your Plan</a>
 </div>
 </section>

 <!-- Bootstrap JS -->
 <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoJtKh7z7lGz7fuP4F8nfdFvAOA6Gg/z6Y5J6XqqyGXYM2ntX5" crossorigin="anonymous"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
</body>
</html>
```