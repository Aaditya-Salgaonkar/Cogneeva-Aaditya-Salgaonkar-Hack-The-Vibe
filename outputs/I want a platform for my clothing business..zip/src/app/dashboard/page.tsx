```
import React from 'react';
import RevenueCard from './RevenueCard';
import NewUsersCard from './NewUsersCard';
import ActiveSubscriptionsCard from './ActiveSubscriptionsCard';
import RecentActivityTable from './RecentActivityTable';
import ChartsPlaceholder from './ChartsPlaceholder';

function Dashboard() {
  return (
    <div className="flex flex-col md:flex-row gap-4">
      <RevenueCard />
      <NewUsersCard />
      <ActiveSubscriptionsCard />